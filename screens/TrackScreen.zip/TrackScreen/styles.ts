import styled from 'styled-components/native'
import { WhiteSectionTitle } from '@styles'

export const Description = styled(WhiteSectionTitle)`
  margin: 30px;
`
